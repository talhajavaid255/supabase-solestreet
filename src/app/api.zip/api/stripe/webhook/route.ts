import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { stripe } from "@/lib/stripe/server";
import { adminSupabase } from "@/lib/stripe/admin";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const signature = request.headers.get("stripe-signature");
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!signature || !secret) return new NextResponse("Webhook config missing", {status:400});

  let event: Stripe.Event;
  try {
    const rawBody = await request.text();
    event = stripe().webhooks.constructEvent(rawBody,signature,secret);
  } catch {
    return new NextResponse("Invalid signature", {status:400});
  }
  if (event.livemode) return new NextResponse("Live events not supported", {status:400});
  if (event.type !== "checkout.session.completed" && event.type !== "checkout.session.expired") {
    return NextResponse.json({received:true,ignored:true});
  }

  const session = event.data.object as Stripe.Checkout.Session;
  if (session.mode !== "payment") return new NextResponse("Unexpected mode", {status:400});
  if (event.type === "checkout.session.completed" && session.payment_status !== "paid") {
    // Card-only flow should be paid at completion; don't mark unpaid/async as paid.
    return new NextResponse("Payment not yet paid", {status:503});
  }
  const intent = typeof session.payment_intent === "string"
    ? session.payment_intent : session.payment_intent?.id ?? null;
  const admin = adminSupabase();
  const { data, error } = await admin.rpc("finalize_stripe_checkout", {
    p_event_id: event.id,
    p_event_type: event.type,
    p_session_id: session.id,
    p_payment_intent_id: intent,
    p_amount_total: session.amount_total,
    p_currency: session.currency,
  });
  if (error) {
    console.error("Webhook reconciliation failed",event.id,session.id,error.message);
    return new NextResponse("Reconciliation failed; retry",{status:500});
  }
  return NextResponse.json({received:true,result:data});
}
